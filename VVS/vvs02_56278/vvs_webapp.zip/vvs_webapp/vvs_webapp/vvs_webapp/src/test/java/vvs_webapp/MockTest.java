package vvs_webapp;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import webapp.services.ApplicationException;
import webapp.services.CustomerServiceMock;
import webapp.webpresentation.UpdateCustomerContactsPageControllerMock;

import javax.servlet.RequestDispatcher;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import static org.mockito.Mockito.*;

public class MockTest {

    private UpdateCustomerContactsPageControllerMock controller;
    private CustomerServiceMock customerServiceMock;
    private HttpServletRequest requestMock;
    private HttpServletResponse responseMock;
    private RequestDispatcher requestDispatcherMock;

    @BeforeEach
    public void setUp() {
        customerServiceMock = mock(CustomerServiceMock.class);
        controller = new UpdateCustomerContactsPageControllerMock(customerServiceMock);
        requestMock = mock(HttpServletRequest.class);
        responseMock = mock(HttpServletResponse.class);
        requestDispatcherMock = mock(RequestDispatcher.class);
    }

    @Test
    public void testUpdateCustomerContactSuccess() throws Exception {
        // Arrange
        when(requestMock.getParameter("vat")).thenReturn("123456789");
        when(requestMock.getParameter("phone")).thenReturn("987654321");
        when(requestMock.getRequestDispatcher("success.jsp")).thenReturn(requestDispatcherMock);

        // Act
        controller.process(requestMock, responseMock);

        // Assert
        verify(customerServiceMock, times(1)).updateCustomerPhone(123456789, 987654321);
        verify(requestMock).setAttribute("message", "Customer contact updated");
        verify(requestDispatcherMock).forward(requestMock, responseMock);
    }

    @Test
    public void testUpdateCustomerContactFailure() throws Exception {
        // Arrange
        when(requestMock.getParameter("vat")).thenReturn("123456789");
        when(requestMock.getParameter("phone")).thenReturn("987654321");
        when(requestMock.getRequestDispatcher("error.jsp")).thenReturn(requestDispatcherMock);

        doThrow(new ApplicationException("Customer not found")).when(customerServiceMock).updateCustomerPhone(123456789, 987654321);

        // Act
        controller.process(requestMock, responseMock);

        // Assert
        verify(customerServiceMock, times(1)).updateCustomerPhone(123456789, 987654321);
        verify(requestMock).setAttribute("error", "Customer not found");
        verify(requestDispatcherMock).forward(requestMock, responseMock);
    }
}
