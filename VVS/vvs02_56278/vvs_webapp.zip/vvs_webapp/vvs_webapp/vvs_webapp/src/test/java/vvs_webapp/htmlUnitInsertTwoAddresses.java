package vvs_webapp;

import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.Test;
import org.junit.jupiter.api.BeforeEach;
import static org.junit.Assert.*;
import com.gargoylesoftware.htmlunit.BrowserVersion;
import com.gargoylesoftware.htmlunit.HttpMethod;
import com.gargoylesoftware.htmlunit.NicelyResynchronizingAjaxController;
import com.gargoylesoftware.htmlunit.Page;
import com.gargoylesoftware.htmlunit.WebClient;
import com.gargoylesoftware.htmlunit.WebRequest;
import com.gargoylesoftware.htmlunit.html.*;
import com.gargoylesoftware.htmlunit.util.NameValuePair;

import java.io.IOException;
import java.net.MalformedURLException;
import java.util.List;
import java.util.Random;

public class htmlUnitInsertTwoAddresses {
	
	private static WebClient webClient;
	private static HtmlPage page;
	
	@BeforeClass
	public static void setUpClass() throws Exception {
		
		webClient = new WebClient(BrowserVersion.getDefault());
		
		// possible configurations needed to prevent JUnit tests to fail for complex HTML pages
        webClient.setJavaScriptTimeout(15000);
        webClient.getOptions().setJavaScriptEnabled(true);
        webClient.getOptions().setThrowExceptionOnScriptError(false);
        webClient.getOptions().setThrowExceptionOnFailingStatusCode(false);
        webClient.getOptions().setCssEnabled(false);
        webClient.setAjaxController(new NicelyResynchronizingAjaxController());
        
		page = webClient.getPage("http://localhost:8080/VVS_webappdemo/index.html");
		assertEquals(200, page.getWebResponse().getStatusCode()); // OK status
		
		 }
	
	@AfterClass
	public static void takeDownClass() {
		webClient.close();
	}
	
	@Test
    public void testInsertTwoAddresses() throws Exception {
		Random random = new Random();
		/*
		 * One of the bugs iv'e corrected is the fact that it accepted EXACTLY the same address, that no longer is the case
		 * Remember that even if small there's a chance of the Address being repeated and the tests fail, just run it again
		 * 
		 * */
		String Postal1 = generateRandomPostalCode();
		String Postal2 = generateRandomPostalCode();
		
		String door1 = String.valueOf(random.nextInt(100));
		String door2 = String.valueOf(random.nextInt(100));
		
	    HtmlAnchor getAddressesLink = page.getAnchorByHref("getCustomerByVAT.html");
	    HtmlPage nextPage = getAddressesLink.click();
	    assertEquals("Enter Name", nextPage.getTitleText());

	    HtmlForm insertCustomerVat = nextPage.getForms().get(0);
	    HtmlInput vatInput = insertCustomerVat.getInputByName("vat");
	    vatInput.setValueAttribute("197672337");

	    HtmlInput submit = insertCustomerVat.getInputByName("submit");
	    HtmlPage reportPage = submit.click();

	    
	    //makes sure that if the table does not exist i.e on the first test run the customer has no associated address the initial table number is 0
	    int initialRowCount = 0;
	    
	    List<Object> tables = reportPage.getByXPath("//table[@class='w3-table w3-bordered']");
	    if (!tables.isEmpty()) {
	        HtmlTable addressTable = (HtmlTable) tables.get(0);
	        initialRowCount = addressTable.getRowCount() - 1;
	    }
		
		insertAddress("197672337", "Rua da Julia", door1, Postal1, "Quarteira");
		insertAddress("197672337", "Avenida do crime", door2, Postal2, "Queluz");
		
		 // Refresh the page to get the updated table
	    nextPage = getAddressesLink.click();
	    assertEquals("Enter Name", nextPage.getTitleText());

	    insertCustomerVat = nextPage.getForms().get(0);
	    vatInput = insertCustomerVat.getInputByName("vat");
	    vatInput.setValueAttribute("197672337");

	    submit = insertCustomerVat.getInputByName("submit");
	    reportPage = submit.click();

	    HtmlTable addressTable = (HtmlTable) reportPage.getByXPath("//table[@class='w3-table w3-bordered']").get(0);
	    int newRowCount = addressTable.getRowCount() - 1;
	    
	    HtmlTableRow row1 = addressTable.getRow(newRowCount - 1);
	    HtmlTableRow row2 = addressTable.getRow(newRowCount);

	    assertEquals(row1.getCell(0).asText(),"Rua da Julia");
	    assertEquals(row1.getCell(1).asText(),door1);
	    assertEquals(row1.getCell(2).asText(),Postal1);
	    assertEquals(row1.getCell(3).asText(),"Quarteira");

	    assertEquals(row2.getCell(0).asText(),"Avenida do crime");
	    assertEquals(row2.getCell(1).asText(),door2);
	    assertEquals(row2.getCell(2).asText(),Postal2);
	    assertEquals(row2.getCell(3).asText(),"Queluz");

	    // Ensure the row count increased by 2
	    assertEquals(initialRowCount + 2, newRowCount);
    }

    private void insertAddress(String vat, String address, String door, String postalCode, String locality) throws IOException {
    	
        HtmlAnchor addAddressLink = page.getAnchorByHref("addAddressToCustomer.html");
        HtmlPage nextPage = addAddressLink.click();
        assertEquals("Enter Address", nextPage.getTitleText());

        HtmlForm addAddressForm = nextPage.getForms().get(0);

        HtmlInput vatInput = addAddressForm.getInputByName("vat");
        vatInput.setValueAttribute(vat);        
        HtmlInput addressInput = addAddressForm.getInputByName("address");
        addressInput.setValueAttribute(address);        
        HtmlInput doorInput = addAddressForm.getInputByName("door");
        doorInput.setValueAttribute(door);        
        HtmlInput postalCodeInput = addAddressForm.getInputByName("postalCode");
        postalCodeInput.setValueAttribute(postalCode);     
        HtmlInput localityInput = addAddressForm.getInputByName("locality");
        localityInput.setValueAttribute(locality);

        HtmlSubmitInput submit = (HtmlSubmitInput) addAddressForm.getInputByValue("Insert");
        Page reportPage = submit.click();
 
    }
    
    /*
     * Generates a random postal code
     * */
    private String generateRandomPostalCode() {
        Random random = new Random();

        // Generate the first part: a 4-digit number
        int firstPart = random.nextInt(9000) + 1000; // Ensures the number is between 1000 and 9999

        // Generate the second part: a 3-digit number
        int secondPart = random.nextInt(900) + 100; // Ensures the number is between 100 and 999

        // Format the string as "####-###"
        return String.format("%04d-%03d", firstPart, secondPart);
    }


}
