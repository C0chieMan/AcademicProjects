package vvs_webapp;

import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.Test;
import org.junit.jupiter.api.BeforeEach;
import static org.junit.Assert.*;
import com.gargoylesoftware.htmlunit.BrowserVersion;
import com.gargoylesoftware.htmlunit.HttpMethod;
import com.gargoylesoftware.htmlunit.NicelyResynchronizingAjaxController;
import com.gargoylesoftware.htmlunit.Page;
import com.gargoylesoftware.htmlunit.TextPage;
import com.gargoylesoftware.htmlunit.WebClient;
import com.gargoylesoftware.htmlunit.WebRequest;
import com.gargoylesoftware.htmlunit.html.*;
import com.gargoylesoftware.htmlunit.util.NameValuePair;

import java.io.IOException;
import java.net.MalformedURLException;

public class htmlUnitNewSaleTest {
	
	private static WebClient webClient;
	private static HtmlPage page;
	
	@BeforeClass
	public static void setUpClass() throws Exception {
		
		webClient = new WebClient(BrowserVersion.getDefault());
		
		// possible configurations needed to prevent JUnit tests to fail for complex HTML pages
        webClient.setJavaScriptTimeout(15000);
        webClient.getOptions().setJavaScriptEnabled(true);
        webClient.getOptions().setThrowExceptionOnScriptError(false);
        webClient.getOptions().setThrowExceptionOnFailingStatusCode(false);
        webClient.getOptions().setCssEnabled(false);
        webClient.setAjaxController(new NicelyResynchronizingAjaxController());
        
		page = webClient.getPage("http://localhost:8080/VVS_webappdemo/index.html");
		assertEquals(200, page.getWebResponse().getStatusCode()); // OK status
		
		 }
	
	@AfterClass
	public static void takeDownClass() {
		webClient.close();
	}
	
	@Test
    public void testNewSaleIsListedAsOpen() throws Exception {
        insertSale("197672337");

        HtmlAnchor getSalesLink = page.getAnchorByHref("getSales.html");
        HtmlPage nextPage = getSalesLink.click();
        assertEquals("Enter Name", nextPage.getTitleText());

        HtmlForm insertCustomerVat = nextPage.getForms().get(0);
        HtmlInput vatInput = insertCustomerVat.getInputByName("customerVat");
        vatInput.setValueAttribute("197672337");

        HtmlSubmitInput submit = (HtmlSubmitInput) insertCustomerVat.getInputByValue("Get Sales");
        HtmlPage salesPage = submit.click();

     // Locate the sales table by class
        HtmlTable salesTable = (HtmlTable) salesPage.getByXPath("//table[@class='w3-table w3-bordered']").get(0);
        int lastRowIndex = salesTable.getRowCount() - 1;
        String salesId =(String)salesTable.getRow(lastRowIndex).getCell(0).asText();
        
     // Check the first row (assuming the first row is for sale ID 1)
        HtmlTableRow row1 = salesTable.getRow(lastRowIndex);
        assertEquals(salesId, row1.getCell(0).asText());
        //assertEquals("2024-05-18", row1.getCell(1).asText()); //A data encontra-se comentada pois muda conforme o dia, para testar atualizar para a data atual
        assertEquals("0.0", row1.getCell(2).asText());
        assertEquals("O", row1.getCell(3).asText());
        assertEquals("197672337", row1.getCell(4).asText());

    }
	
	private void insertSale(String vat) throws IOException, InterruptedException {
        HtmlAnchor addSaleLink = page.getAnchorByHref("addSale.html");
        HtmlPage nextPage = addSaleLink.click();
        assertEquals("New Sale", nextPage.getTitleText());

        HtmlForm addSaleForm = nextPage.getForms().get(0);

        HtmlInput vatInput = addSaleForm.getInputByName("customerVat");
        vatInput.setValueAttribute(vat);
        
        HtmlSubmitInput submit = (HtmlSubmitInput) addSaleForm.getInputByValue("Add Sale");
        Page reportPage = submit.click();
        
    }
	
	
	
}


