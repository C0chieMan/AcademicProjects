package vvs_webapp;

import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.Test;
import org.junit.jupiter.api.BeforeEach;
import static org.junit.Assert.*;
import com.gargoylesoftware.htmlunit.BrowserVersion;
import com.gargoylesoftware.htmlunit.HttpMethod;
import com.gargoylesoftware.htmlunit.NicelyResynchronizingAjaxController;
import com.gargoylesoftware.htmlunit.Page;
import com.gargoylesoftware.htmlunit.TextPage;
import com.gargoylesoftware.htmlunit.WebClient;
import com.gargoylesoftware.htmlunit.WebRequest;
import com.gargoylesoftware.htmlunit.html.*;
import com.gargoylesoftware.htmlunit.util.NameValuePair;

import java.io.IOException;
import java.net.MalformedURLException;

/*
 * In order for this test to work at least on sale must exist
 * Since the db always resets when the server is activated and there's 2 default customers with no sales
 * This test is met to be run once the server as been restored and the user has no sales associated with it
 * */

public class htmlUnitTestCloseSale {
	
	private static WebClient webClient;
	private static HtmlPage page;
	
	@BeforeClass
	public static void setUpClass() throws Exception {
		
		webClient = new WebClient(BrowserVersion.getDefault());
		
		// possible configurations needed to prevent JUnit tests to fail for complex HTML pages
        webClient.setJavaScriptTimeout(15000);
        webClient.getOptions().setJavaScriptEnabled(true);
        webClient.getOptions().setThrowExceptionOnScriptError(false);
        webClient.getOptions().setThrowExceptionOnFailingStatusCode(false);
        webClient.getOptions().setCssEnabled(false);
        webClient.setAjaxController(new NicelyResynchronizingAjaxController());
        
		page = webClient.getPage("http://localhost:8080/VVS_webappdemo/index.html");
		assertEquals(200, page.getWebResponse().getStatusCode()); // OK status
			
		 }
	
	@AfterClass
	public static void takeDownClass() {
		webClient.close();
	}
	
	@Test
    public void testCloseSale() throws Exception {
		insertSale("197672337");

	    // Test existing sale which is currently open
	    HtmlAnchor getSalesLink = page.getAnchorByHref("getSales.html");
	    HtmlPage nextPage = getSalesLink.click();
	    assertEquals("Enter Name", nextPage.getTitleText());

	    HtmlForm insertCustomerVat = nextPage.getForms().get(0);
	    HtmlInput vatInput = insertCustomerVat.getInputByName("customerVat");
	    vatInput.setValueAttribute("197672337");

	    HtmlSubmitInput submit = (HtmlSubmitInput) insertCustomerVat.getInputByValue("Get Sales");
	    HtmlPage salesPage = submit.click();

	    // Locate the sales table by class
	    HtmlTable salesTable = (HtmlTable) salesPage.getByXPath("//table[@class='w3-table w3-bordered']").get(0);
	    int lastRowIndex = salesTable.getRowCount() - 1;
	    String salesId =(String)salesTable.getRow(lastRowIndex).getCell(0).asText();

	    // Check the last row (assuming the last row is the newly inserted sale)
	    HtmlTableRow row1 = salesTable.getRow(lastRowIndex);

	    assertEquals(salesId, row1.getCell(0).asText());
	    // assertEquals("2024-05-18", row1.getCell(1).asText()); // Uncomment and update date for testing
	    assertEquals("0.0", row1.getCell(2).asText());
	    assertEquals("O", row1.getCell(3).asText());
	    assertEquals("197672337", row1.getCell(4).asText());

	    // Close the newly inserted sale
	    closeSale(salesId);

	    // Refresh the page to check the updated status of the sale
	    nextPage = getSalesLink.click();
	    assertEquals("Enter Name", nextPage.getTitleText());

	    insertCustomerVat = nextPage.getForms().get(0);
	    vatInput = insertCustomerVat.getInputByName("customerVat");
	    vatInput.setValueAttribute("197672337");

	    submit = (HtmlSubmitInput) insertCustomerVat.getInputByValue("Get Sales");
	    salesPage = submit.click();

	    // Locate the sales table by class
	    salesTable = (HtmlTable) salesPage.getByXPath("//table[@class='w3-table w3-bordered']").get(0);
	    lastRowIndex = salesTable.getRowCount() - 1;

	    // Check the last row again (should be the same sale, now closed)
	    row1 = salesTable.getRow(lastRowIndex);

	    assertEquals(salesId, row1.getCell(0).asText());
	    // assertEquals("2024-05-18", row1.getCell(1).asText()); // Uncomment and update date for testing
	    assertEquals("0.0", row1.getCell(2).asText());
	    assertEquals("C", row1.getCell(3).asText());
	    assertEquals("197672337", row1.getCell(4).asText());

    }

    private void closeSale(String saleId) throws IOException, InterruptedException {
        HtmlAnchor closeSaleLink = page.getAnchorByHref("UpdateSaleStatusPageControler");
        HtmlPage nextPage = closeSaleLink.click();
        assertEquals("Enter Sale Id", nextPage.getTitleText());

        HtmlForm closeSaleForm = nextPage.getForms().get(0);
        
        HtmlInput idInput = closeSaleForm.getInputByName("id");
        idInput.setValueAttribute(saleId);
        
        HtmlSubmitInput submit = (HtmlSubmitInput) closeSaleForm.getInputByValue("Close Sale");
        Page reportPage = submit.click();
        
        webClient.waitForBackgroundJavaScript(10000); //
    }
    
    private static void insertSale(String vat) throws IOException, InterruptedException {
        HtmlAnchor addSaleLink = page.getAnchorByHref("addSale.html");
        HtmlPage nextPage = addSaleLink.click();
        assertEquals("New Sale", nextPage.getTitleText());

        HtmlForm addSaleForm = nextPage.getForms().get(0);

        HtmlInput vatInput = addSaleForm.getInputByName("customerVat");
        vatInput.setValueAttribute(vat);
        
        HtmlSubmitInput submit = (HtmlSubmitInput) addSaleForm.getInputByValue("Add Sale");
        Page reportPage = submit.click();
        
        webClient.waitForBackgroundJavaScript(10000);
        
    }
    
}
