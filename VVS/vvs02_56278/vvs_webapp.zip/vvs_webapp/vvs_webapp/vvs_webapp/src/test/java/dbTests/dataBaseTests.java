package dbTests;

import static org.junit.Assert.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static dbTests.DBSetupUtils.DB_PASSWORD;
import static dbTests.DBSetupUtils.DB_URL;
import static dbTests.DBSetupUtils.DB_USERNAME;
import static dbTests.DBSetupUtils.DELETE_ALL;
import static dbTests.DBSetupUtils.INSERT_CUSTOMER_ADDRESS_DATA;
import static dbTests.DBSetupUtils.NUM_INIT_SALES;
import static dbTests.DBSetupUtils.startApplicationDatabaseForTesting;


import java.sql.SQLException;
import java.util.List;
import java.util.stream.Collectors;

import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import com.ninja_squad.dbsetup.DbSetup;
import com.ninja_squad.dbsetup.DbSetupTracker;
import com.ninja_squad.dbsetup.Operations;
import com.ninja_squad.dbsetup.destination.Destination;
import com.ninja_squad.dbsetup.destination.DriverManagerDestination;
import com.ninja_squad.dbsetup.operation.Operation;

import vvs_webapp.VATGenerator;
import webapp.services.AddressDTO;
import webapp.services.AddressesDTO;
import webapp.services.ApplicationException;
import webapp.services.CustomerDTO;
import webapp.services.CustomerService;
import webapp.services.SaleDTO;
import webapp.services.SaleService;
import webapp.services.SalesDTO;

public class dataBaseTests {
	private static Destination dataSource;

	// the tracker is static because JUnit uses a separate Test instance for every
	// test method.
	private static DbSetupTracker dbSetupTracker = new DbSetupTracker();

	@BeforeClass
	public static void setupClass() {
		startApplicationDatabaseForTesting();
		dataSource = DriverManagerDestination.with(DB_URL, DB_USERNAME, DB_PASSWORD);
	}

	@Before
	public void setup() throws SQLException {

		Operation initDBOperations = Operations.sequenceOf(DELETE_ALL, INSERT_CUSTOMER_ADDRESS_DATA);

		DbSetup dbSetup = new DbSetup(dataSource, initDBOperations);

		// Use the tracker to launch the DbSetup. This will speed-up tests
		// that do not not change the BD. Otherwise, just use dbSetup.launch();
		dbSetupTracker.launchIfNecessary(dbSetup);

	}
	
	@Test
	 public void testAddCustomerWithExistingVat() throws ApplicationException {
		final int existingVat = 197672337;
		final String newCustomerName = "ManoVski";
		final int newCustomerPhone = 96942086;

	        // Attempt to add a new customer with an existing VAT number
	        
	       try {
	           // Attempt to add a new customer with an existing VAT number
	           CustomerService.INSTANCE.addCustomer(existingVat, newCustomerName, newCustomerPhone);
	       } catch (ApplicationException e) {}         

	       // Verify the existing customer details remain unchanged
	       assertEquals("JOSE FARIA", CustomerService.INSTANCE.getCustomerByVat(existingVat).designation);
	       assertEquals(existingVat, CustomerService.INSTANCE.getCustomerByVat(existingVat).vat);
	       assertEquals(914276732, CustomerService.INSTANCE.getCustomerByVat(existingVat).phoneNumber);
	       assertEquals(2, CustomerService.INSTANCE.getAllCustomers().customers.size()); //Verifica que a lista não é alterada
	       
	       AddressesDTO addr = CustomerService.INSTANCE.getAllAddresses(existingVat);
	       List<AddressDTO> addressList = addr.addrs;
	       
	       //System.out.println(addressList.get(0).address.split(",")[0]);

	    }
	
	@Test
	 public void testCustomerContactUpdate() throws ApplicationException {
		 final int vat = 197672337;
		 final int oldContact = 914276732;
	     final int newContact = 927558680;
	     
	     assertEquals(oldContact, CustomerService.INSTANCE.getCustomerByVat(vat).phoneNumber);

	     // Update the customer's contact information
	     CustomerService.INSTANCE.updateCustomerPhone(vat, newContact);
	     
	     // Verify that the contact information is updated correctly
	     assertEquals(newContact, CustomerService.INSTANCE.getCustomerByVat(vat).phoneNumber);
	    }
	 
	 @Test
	 public void testDeleteAllCustomers() throws ApplicationException {

		 assertEquals(2, CustomerService.INSTANCE.getAllCustomers().customers.size());
		 	 
		 for(CustomerDTO customer : CustomerService.INSTANCE.getAllCustomers().customers) {
			 CustomerService.INSTANCE.removeCustomer(customer.vat);
		 }
		 
		 assertEquals(0, CustomerService.INSTANCE.getAllCustomers().customers.size());
		 assertEquals(true, CustomerService.INSTANCE.getAllCustomers().customers.isEmpty());

	    }
	 
	 @Test
	 public void testRemoveAndAddCustomer() throws ApplicationException {
		 final int vat = CustomerService.INSTANCE.getAllCustomers().customers.get(0).vat;
		 final String name = CustomerService.INSTANCE.getAllCustomers().customers.get(0).designation;
		 final int phone = CustomerService.INSTANCE.getAllCustomers().customers.get(0).phoneNumber;
		 boolean exceptionThrown = false;
		 
		 CustomerDTO customer = CustomerService.INSTANCE.getCustomerByVat(vat);
		 
		 CustomerService.INSTANCE.removeCustomer(vat);
		 
		 try {
	            CustomerService.INSTANCE.getCustomerByVat(vat);
	        } catch (ApplicationException e) {
	            exceptionThrown = true;
	        }
		 
		 assertEquals(true, exceptionThrown);
		 
		 CustomerService.INSTANCE.addCustomer(vat, name, phone);
		 assertEquals(2, CustomerService.INSTANCE.getAllCustomers().customers.size());
		 assertEquals(customer.designation, CustomerService.INSTANCE.getCustomerByVat(vat).designation);
	     assertEquals(customer.vat, CustomerService.INSTANCE.getCustomerByVat(vat).vat);
	     assertEquals(customer.phoneNumber, CustomerService.INSTANCE.getCustomerByVat(vat).phoneNumber);

	    }
	 
	 @Test
	 public void testAddSaleIncreasesTotalSales() throws ApplicationException {
		 final int vat = 197672337;

	     // Verify initial number of sales
	     int initialSalesCount = SaleService.INSTANCE.getAllSales().sales.size();

	     // Add a new sale
	     SaleService.INSTANCE.addSale(vat);

	     // Verify the number of sales has increased by one
	     int newSalesCount = SaleService.INSTANCE.getAllSales().sales.size();
	     
	     assertEquals(initialSalesCount + 1, newSalesCount);
	    }
	 
	 
	 @Test
	 public void testDeleteCustomerRemovesSales() throws ApplicationException {
		 final int vat = VATGenerator.generateValidVAT();
		 final String newCustomerName = "ManoVski";
		 final int newCustomerPhone = 96942086;
		 
		 // Criar um Customer não existente 
		 try {
			 // Attempt to add a new customer with an existing VAT number
			 CustomerService.INSTANCE.addCustomer(vat, newCustomerName, newCustomerPhone);
			 } catch (ApplicationException e) {}
		 
		 SaleService.INSTANCE.addSale(vat);
		 
		 //user novo com sale recem inserida só tera 1
		 List<SaleDTO> newSale = SaleService.INSTANCE.getSaleByCustomerVat(vat).sales;
		 
		 assertEquals(newSale.size(), 1); //sale criada com sucesso
		 
		 //remove o user
		 CustomerService.INSTANCE.removeCustomer(vat);
		 
		 assertEquals(0, SaleService.INSTANCE.getSaleByCustomerVat(vat).sales.size());

	    }
	    
	 
}