package vvs_webapp;

import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.Test;
import org.junit.jupiter.api.BeforeEach;
import static org.junit.Assert.*;
import com.gargoylesoftware.htmlunit.BrowserVersion;
import com.gargoylesoftware.htmlunit.HttpMethod;
import com.gargoylesoftware.htmlunit.NicelyResynchronizingAjaxController;
import com.gargoylesoftware.htmlunit.Page;
import com.gargoylesoftware.htmlunit.WebClient;
import com.gargoylesoftware.htmlunit.WebRequest;
import com.gargoylesoftware.htmlunit.html.*;
import com.gargoylesoftware.htmlunit.util.NameValuePair;

import java.io.IOException;
import java.net.MalformedURLException;
import java.util.Random;

public class htmlUnitTestSaleDelivery {
	
	private static WebClient webClient;
	private static HtmlPage page;
	
	@BeforeClass
	public static void setUpClass() throws Exception {
		
		webClient = new WebClient(BrowserVersion.getDefault());
		
		// possible configurations needed to prevent JUnit tests to fail for complex HTML pages
        webClient.setJavaScriptTimeout(15000);
        webClient.getOptions().setJavaScriptEnabled(true);
        webClient.getOptions().setThrowExceptionOnScriptError(false);
        webClient.getOptions().setThrowExceptionOnFailingStatusCode(false);
        webClient.getOptions().setCssEnabled(false);
        webClient.setAjaxController(new NicelyResynchronizingAjaxController());
        
		page = webClient.getPage("http://localhost:8080/VVS_webappdemo/index.html");
		assertEquals(200, page.getWebResponse().getStatusCode()); // OK status
		
		 }
	
	@AfterClass
	public static void takeDownClass() {
		webClient.close();
	}
	
	@Test
	public void testSaleDelivery() throws Exception {
		Random random = new Random();
		String phoneNumber = String.valueOf(100000000 + random.nextInt(900000000));
		String VAT1 = String.valueOf(VATGenerator.generateValidVAT());

		/*
		 * Random phone number since i altered the code so no repeated cellphones can be inserted
		 * */
		insertCustomer(VAT1, "Vski", phoneNumber);

		HtmlAnchor getCustomersLink = page.getAnchorByHref("GetAllCustomersPageController");
		HtmlPage nextPage = getCustomersLink.click();
		assertEquals("Customers Info", nextPage.getTitleText());
		assertTrue(nextPage.asText().contains("Vski"));
		assertTrue(nextPage.asText().contains(VAT1));
		assertTrue(nextPage.asText().contains(phoneNumber));

		insertAddress(VAT1, "Rua da Julia", "12", "8125-101", "Quarteira");

		HtmlAnchor getAddressesLink = page.getAnchorByHref("getCustomerByVAT.html");
		nextPage = getAddressesLink.click();
		assertEquals("Enter Name", nextPage.getTitleText());

		HtmlForm insertCustomerVat = nextPage.getForms().get(0);
		HtmlInput vatInput = insertCustomerVat.getInputByName("vat");
		vatInput.setValueAttribute(VAT1);

		HtmlInput submit = insertCustomerVat.getInputByName("submit");
		HtmlPage reportPage = submit.click();

		// Locate the table by class
		HtmlTable addressTable = (HtmlTable) reportPage.getByXPath("//table[@class='w3-table w3-bordered']").get(0);
		int newAddressRow= addressTable.getRowCount() - 1;
		HtmlTableRow row1 = addressTable.getRow(newAddressRow);
		    
		assertEquals(row1.getCell(0).asText(),"Rua da Julia");
	    assertEquals(row1.getCell(1).asText(),"12");
	    assertEquals(row1.getCell(2).asText(),"8125-101");
	    assertEquals(row1.getCell(3).asText(),"Quarteira");

		insertSale(VAT1);

		HtmlAnchor getSalesLink = page.getAnchorByHref("getSales.html");
		nextPage = getSalesLink.click();
		assertEquals("Enter Name", nextPage.getTitleText());

		insertCustomerVat = nextPage.getForms().get(0);
		vatInput = insertCustomerVat.getInputByName("customerVat");
		vatInput.setValueAttribute(VAT1);

		submit = (HtmlSubmitInput) insertCustomerVat.getInputByValue("Get Sales");
		HtmlPage salesPage = submit.click();

		// Locate the sales table by class
		HtmlTable salesTable = (HtmlTable) salesPage.getByXPath("//table[@class='w3-table w3-bordered']").get(0);
		int lastSaleRowIndex = salesTable.getRowCount() - 1;

		HtmlTableRow lastSaleRow = salesTable.getRow(lastSaleRowIndex);
		assertTrue(lastSaleRow.asText().contains(VAT1));
		assertTrue(lastSaleRow.asText().contains("0.0"));
		assertTrue(lastSaleRow.asText().contains("O"));

		insertDelivery(VAT1);

		HtmlAnchor getDeliveryLink = page.getAnchorByHref("showDelivery.html");
		nextPage = getDeliveryLink.click();

		insertCustomerVat = nextPage.getForms().get(0);

		vatInput = insertCustomerVat.getInputByName("vat");
		vatInput.setValueAttribute(VAT1);

		submit = (HtmlSubmitInput) insertCustomerVat.getInputByValue("Get Customer");
		HtmlPage finalPage = submit.click();

		HtmlTable finalTable = (HtmlTable) finalPage.getByXPath("//table[@class='w3-table w3-bordered']").get(0);
		int finalRowIndex = finalTable.getRowCount() - 1;

		HtmlTableRow finalRow = finalTable.getRow(finalRowIndex);
		assertEquals(lastSaleRow.getCell(0).asText(), finalRow.getCell(1).asText());
		// Ensure the row count increased by 1
		assertEquals(1, finalTable.getRowCount() - 1);
    }
	
	private void insertCustomer(String vat, String designation, String phone) throws IOException, InterruptedException {
        
        HtmlAnchor addCustomerLink = page.getAnchorByHref("addCustomer.html");
        HtmlPage nextPage = addCustomerLink.click();
        
        assertEquals("Enter Name", nextPage.getTitleText());
                
        HtmlForm addCustomerForm = nextPage.getForms().get(0);
        
        HtmlInput vatInput = addCustomerForm.getInputByName("vat");
        vatInput.setValueAttribute(vat);
        HtmlInput designationInput = addCustomerForm.getInputByName("designation");
        designationInput.setValueAttribute(designation);
        HtmlInput phoneInput = addCustomerForm.getInputByName("phone");
        phoneInput.setValueAttribute(phone);
        
        HtmlInput submit = addCustomerForm.getInputByName("submit");

        HtmlPage reportPage = submit.click();
        String textReportPage = reportPage.asText();
        assertEquals("Customer Info", reportPage.getTitleText());
        assertTrue(textReportPage.contains(designation));
        assertTrue(textReportPage.contains(phone));
        
        //webClient.wait((long)3000);
    }
	
	private void insertSale(String vat) throws IOException, InterruptedException {
        HtmlAnchor addSaleLink = page.getAnchorByHref("addSale.html");
        HtmlPage nextPage = addSaleLink.click();
        assertEquals("New Sale", nextPage.getTitleText());

        HtmlForm addSaleForm = nextPage.getForms().get(0);

        HtmlInput vatInput = addSaleForm.getInputByName("customerVat");
        vatInput.setValueAttribute(vat);
        
        HtmlSubmitInput submit = (HtmlSubmitInput) addSaleForm.getInputByValue("Add Sale");
        Page reportPage = submit.click();
        
        //webClient.wait((long)3000);
    }
	
	private void insertAddress(String vat, String address, String door, String postalCode, String locality) throws IOException {
    	
        HtmlAnchor addAddressLink = page.getAnchorByHref("addAddressToCustomer.html");
        HtmlPage nextPage = addAddressLink.click();
        assertEquals("Enter Address", nextPage.getTitleText());

        HtmlForm addAddressForm = nextPage.getForms().get(0);

        HtmlInput vatInput = addAddressForm.getInputByName("vat");
        vatInput.setValueAttribute(vat);        
        HtmlInput addressInput = addAddressForm.getInputByName("address");
        addressInput.setValueAttribute(address);        
        HtmlInput doorInput = addAddressForm.getInputByName("door");
        doorInput.setValueAttribute(door);        
        HtmlInput postalCodeInput = addAddressForm.getInputByName("postalCode");
        postalCodeInput.setValueAttribute(postalCode);     
        HtmlInput localityInput = addAddressForm.getInputByName("locality");
        localityInput.setValueAttribute(locality);

        HtmlSubmitInput submit = (HtmlSubmitInput) addAddressForm.getInputByValue("Insert");
        Page reportPage = submit.click();
 
    }
	
	private void insertDelivery(String vat) throws IOException {
    	
        HtmlAnchor addAddressLink = page.getAnchorByHref("saleDeliveryVat.html");
        HtmlPage nextPage = addAddressLink.click();
        assertEquals("Enter Name", nextPage.getTitleText());

        HtmlForm addVatForm = nextPage.getForms().get(0);

        HtmlInput vatInput = addVatForm.getInputByName("vat");
        vatInput.setValueAttribute(vat);
        
        HtmlSubmitInput submit = (HtmlSubmitInput) addVatForm.getInputByValue("Get Customer");
        HtmlPage reportPage = submit.click();
        assertEquals("Enter Name", reportPage.getTitleText());
        
     // Extract the most recent address ID from the addresses table
        HtmlTable addressTable = (HtmlTable) reportPage.getByXPath("//table[@class='w3-table w3-bordered']").get(0);
        int lastAddressRowIndex = addressTable.getRowCount() - 1;
        String addressId =(String)addressTable.getRow(lastAddressRowIndex).getCell(0).asText();

        // Extract the most recent sale ID from the sales table
        HtmlTable salesTable = (HtmlTable) reportPage.getByXPath("//table[@class='w3-table w3-bordered']").get(1);
        int lastSaleRowIndex = salesTable.getRowCount() - 1;
        String saleId = (String)salesTable.getRow(lastSaleRowIndex).getCell(0).asText();
        
        HtmlForm addDeliveryForm = reportPage.getForms().get(0);
        
        HtmlInput idAddress = addDeliveryForm.getInputByName("addr_id");
        idAddress.setValueAttribute(addressId);
        
        HtmlInput idSale = addDeliveryForm.getInputByName("sale_id");
        idSale.setValueAttribute(saleId);
        
        submit = (HtmlSubmitInput) addDeliveryForm.getInputByValue("Insert");
        HtmlPage finalPage = submit.click();
    }

	
	

}
