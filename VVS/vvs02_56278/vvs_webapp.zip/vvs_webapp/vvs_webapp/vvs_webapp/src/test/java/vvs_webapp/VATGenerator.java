package vvs_webapp;

import java.util.Random;


/*
 * Esta classe foi feita com o auxílio do ChatGPT
 * */
public class VATGenerator {
    
    private static final int[] VALID_FIRST_DIGITS = {1, 2, 5, 6, 8, 9};
    private static final Random RANDOM = new Random();

    /**
     * Generates a random valid VAT number.
     * 
     * @return A valid VAT number.
     */
    public static int generateValidVAT() {
    	int vat;
    	
    	do {
	        int firstDigit = VALID_FIRST_DIGITS[RANDOM.nextInt(VALID_FIRST_DIGITS.length)];
	        vat = firstDigit * 100000000 + RANDOM.nextInt(100000000);
	
	        // Calculate the check digit
	        int sum = 0;
	        int tempVAT = vat;
	        
	        for (int i = 2; i < 10 && tempVAT != 0; i++) {
	            sum += (tempVAT % 10) * i;
	            tempVAT /= 10;
	        }
	
	        int checkDigitCalc = 11 - (sum % 11);
	        if (checkDigitCalc == 10) {
	            checkDigitCalc = 0;
	        } else if (checkDigitCalc == 11) {
	            checkDigitCalc = 1;
	        }
	
	        vat = vat / 10 * 10 + checkDigitCalc;
	        
    	} while(!isValidVAT(vat));
        return vat;
    }

    /**
	 * Checks if a VAT number is valid.
	 * 
	 * @param vat The number to be checked.
	 * @return Whether the VAT number is valid. 
	 */
	private static boolean isValidVAT(int vat) {
		// If the number of digits is not 9, error!
		if (vat < 100000000 || vat > 999999999)
			return false;
		
		// If the first number is not 1, 2, 5, 6, 8, 9, error!
		int firstDigit = vat / 100000000;
		if (firstDigit != 1 && firstDigit != 2 && 
			firstDigit != 5 && firstDigit != 6 &&
			firstDigit != 8 && firstDigit != 9)
			return false;
		
		// Checks the congruence modules 11.
		int sum = 0;
		int checkDigit = vat % 10;
		vat /= 10;
		
		for (int i = 2; i < 10 && vat != 0; i++) {
			sum += vat % 10 * i;
			vat /= 10;
		}
		
		int checkDigitCalc = 11 - sum % 11;
		if (checkDigitCalc == 10)
			checkDigitCalc = 0;
		return checkDigit == checkDigitCalc;
	}

    public static void main(String[] args) {
        // Generate and print some valid VAT numbers for testing
        for (int i = 0; i < 10; i++) {
            int vat = generateValidVAT();
            System.out.println("Generated VAT: " + vat + " is valid: " + isValidVAT(vat));
        }
    }
}