package vvs_webapp;

import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.Test;
import org.junit.jupiter.api.BeforeEach;
import static org.junit.Assert.*;
import com.gargoylesoftware.htmlunit.BrowserVersion;
import com.gargoylesoftware.htmlunit.HttpMethod;
import com.gargoylesoftware.htmlunit.NicelyResynchronizingAjaxController;
import com.gargoylesoftware.htmlunit.WebClient;
import com.gargoylesoftware.htmlunit.WebRequest;
import com.gargoylesoftware.htmlunit.html.*;
import com.gargoylesoftware.htmlunit.util.NameValuePair;

import java.io.IOException;
import java.net.MalformedURLException;
import java.util.Random;


/*
 * Este teste pode correr as vezes necessárias sem ter de reiniciar a bd
 * 
 * */
public class htmlUnitInsertTwoCustomers {
	
private static WebClient webClient;
private static HtmlPage page;
	
	@BeforeClass
	public static void setUpClass() throws Exception {
		
		webClient = new WebClient(BrowserVersion.getDefault());
		
		// possible configurations needed to prevent JUnit tests to fail for complex HTML pages
        webClient.setJavaScriptTimeout(15000);
        webClient.getOptions().setJavaScriptEnabled(true);
        webClient.getOptions().setThrowExceptionOnScriptError(false);
        webClient.getOptions().setThrowExceptionOnFailingStatusCode(false);
        webClient.getOptions().setCssEnabled(false);
        webClient.setAjaxController(new NicelyResynchronizingAjaxController());
        
		page = webClient.getPage("http://localhost:8080/VVS_webappdemo/index.html");
		assertEquals(200, page.getWebResponse().getStatusCode()); // OK status
		
		 }
	
	@AfterClass
	public static void takeDownClass() {
		webClient.close();
	}
	
	/*
	 * Os testes iramm falhar se já existirem estes usares na bda
	 * Remover-los caso existam antes de os correr 
	 * */
	@Test
	public void testInsertTwoCustomers() throws Exception {
		
		Random random = new Random();
		String phoneNumber1 = String.valueOf(100000000 + random.nextInt(900000000));
		String phoneNumber2 = String.valueOf(100000000 + random.nextInt(900000000));
		String VAT1 = String.valueOf(VATGenerator.generateValidVAT());
		String VAT2 = String.valueOf(VATGenerator.generateValidVAT());
        insertCustomer(VAT1, "Vasco", phoneNumber1);
        insertCustomer(VAT2, "Vski", phoneNumber2);

        HtmlAnchor getCustomersLink = page.getAnchorByHref("GetAllCustomersPageController");
        HtmlPage nextPage = getCustomersLink.click();
        assertEquals("Customers Info", nextPage.getTitleText());

        assertTrue(nextPage.asText().contains("Vasco"));
        assertTrue(nextPage.asText().contains(VAT1));
        assertTrue(nextPage.asText().contains(phoneNumber1));
        assertTrue(nextPage.asText().contains("Vski"));
        assertTrue(nextPage.asText().contains(VAT2));
        assertTrue(nextPage.asText().contains(phoneNumber2));
        
        //removes the created customers to reset the db to it's initial state
        removeCustomer(VAT1);
        removeCustomer(VAT2);
	    }
	 
	 private void insertCustomer(String vat, String designation, String phone) throws IOException {
	        
	        HtmlAnchor addCustomerLink = page.getAnchorByHref("addCustomer.html");
	        HtmlPage nextPage = addCustomerLink.click();
	        
	        assertEquals("Enter Name", nextPage.getTitleText());
	                
	        HtmlForm addCustomerForm = nextPage.getForms().get(0);
	        
	        HtmlInput vatInput = addCustomerForm.getInputByName("vat");
	        vatInput.setValueAttribute(vat);
	        HtmlInput designationInput = addCustomerForm.getInputByName("designation");
	        designationInput.setValueAttribute(designation);
	        HtmlInput phoneInput = addCustomerForm.getInputByName("phone");
	        phoneInput.setValueAttribute(phone);
	        
	        HtmlInput submit = addCustomerForm.getInputByName("submit");

	        HtmlPage reportPage = submit.click();
	        String textReportPage = reportPage.asText();
	        assertEquals("Customer Info", reportPage.getTitleText());
	        assertTrue(textReportPage.contains(designation));
	        assertTrue(textReportPage.contains(phone));
	    }
	 
	 private void removeCustomer(String vat) throws IOException {
	        
	        HtmlAnchor addCustomerLink = page.getAnchorByHref("RemoveCustomerPageController");
	        HtmlPage nextPage = addCustomerLink.click();
	        
	        assertEquals("Enter VatNumber", nextPage.getTitleText());
	                
	        HtmlForm addCustomerForm = nextPage.getForms().get(0);
	        
	        HtmlInput vatInput = addCustomerForm.getInputByName("vat");
	        vatInput.setValueAttribute(vat);
	       
	        HtmlInput submit = addCustomerForm.getInputByName("submit");
	        submit.click();
	       
	    }
	 
}


