package webapp.webpresentation;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import webapp.persistence.AddressRowDataGateway;
import webapp.persistence.CustomerFinder;
import webapp.persistence.CustomerRowDataGateway;
import webapp.services.ApplicationException;
import webapp.services.CustomerServiceMock;


@WebServlet("/UpdateCustomerContactsPageController")
public class UpdateCustomerContactsPageControllerMock extends PageController {
    private static final long serialVersionUID = 1L;

    private CustomerServiceMock customerService;

    public UpdateCustomerContactsPageControllerMock() {
        this.customerService = new CustomerServiceMock(new CustomerFinder(), new CustomerRowDataGateway(), new AddressRowDataGateway());
    }

    // For dependency injection during tests
    public UpdateCustomerContactsPageControllerMock(CustomerServiceMock customerService) {
        this.customerService = customerService;
    }

    @Override
	public void process(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        try {
            int vat = Integer.parseInt(request.getParameter("vat").trim());
            int phone = Integer.parseInt(request.getParameter("phone"));
            customerService.updateCustomerPhone(vat, phone);
            request.setAttribute("message", "Customer contact updated");
            request.getRequestDispatcher("success.jsp").forward(request, response);
        } catch (ApplicationException e) {
            request.setAttribute("error", e.getMessage());
            request.getRequestDispatcher("error.jsp").forward(request, response);
        }
    }
}