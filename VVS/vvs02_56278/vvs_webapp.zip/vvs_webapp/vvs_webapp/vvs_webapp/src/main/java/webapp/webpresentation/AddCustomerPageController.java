package webapp.webpresentation;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import webapp.services.ApplicationException;
import webapp.services.CustomerDTO;
import webapp.services.CustomerService;

@WebServlet("/AddCustomerPageController")
public class AddCustomerPageController extends PageController{
	private static final long serialVersionUID = 1L;

	@Override
	protected void process(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		CustomerService cs = CustomerService.INSTANCE;
		
		CustomerHelper ch = new CustomerHelper();
		request.setAttribute("helper", ch);
		
		try{
			String vat = request.getParameter("vat").trim();
			String phone = request.getParameter("phone");
			String designation = request.getParameter("designation").trim();
			if (isInt(ch, vat, "Invalid VAT number") && isInt(ch, phone, "Invalid phone number")) {
				int vatNumber = intValue(vat);
				int phoneNumber = intValue(phone);
				boolean repeated = false;
				
				if(designation.isEmpty()) {
					repeated = true;
				}
				
				List<CustomerDTO> allcd = cs.getAllCustomers().customers;
				
				for(CustomerDTO customer : allcd) {
					if(customer.phoneNumber == phoneNumber) {
						repeated = true;
					}
				}
				if(repeated == true) {
					ch.addMessage("It was not possible to fulfill the request: ");
					ch.fillWithCustomer(cs.getCustomerByVat(vatNumber));
				}else {
					cs.addCustomer(vatNumber, designation, phoneNumber);
					ch.fillWithCustomer(cs.getCustomerByVat(vatNumber));
					request.getRequestDispatcher("CustomerInfo.jsp").forward(request, response);
				}
			}
		} catch (ApplicationException e) {
			ch.addMessage("It was not possible to fulfill the request: " + e.getMessage());
			request.getRequestDispatcher("CustomerError.jsp").forward(request, response); 
		}
	}
}
